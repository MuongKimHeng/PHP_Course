<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Larabook - <?php echo e($title??'Home'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <nav class="nav nav-pills nav-justified mb-4">
        <a class="nav-link <?php echo e(request()->routeIs('topics.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('topics.index')); ?>">Main Page</a>
        <a class="nav-link <?php echo e(request()->routeIs('blocks.*') ? 'active' : ''); ?>"
           href="<?php echo e(route('blocks.create')); ?>">Content Control</a>
    </nav>

    <div class="container">
        
        
        <?php $__env->startSection('content'); ?>
            <h1>Larabook Master</h1>        
        <?php echo $__env->yieldSection(); ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH D:\Work\2026\FTSDE19\PHP\larabook\resources\views/layouts/master.blade.php ENDPATH**/ ?>