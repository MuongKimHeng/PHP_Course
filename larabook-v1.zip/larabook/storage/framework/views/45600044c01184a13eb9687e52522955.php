
<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>
    <h1>Larabook Child</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        h1{color: red}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.querySelector('h1').addEventListener('click', e=>{
            alert('H1 clicked.');
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Work\2026\FTSDE19\PHP\larabook\resources\views/child.blade.php ENDPATH**/ ?>