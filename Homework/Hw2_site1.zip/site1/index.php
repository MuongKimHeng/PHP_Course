<?php
declare(strict_types=1);

// session_start() must be the very first thing that can send output-related
// headers, so it runs before the DOCTYPE / any HTML below.
session_start();

include_once 'pages/functions.php';

$page = $_GET['page'] ?? '1';

// --- Header login form handler --------------------------------------
if (isset($_POST['loginbtn'])) {
    $name = $_POST['login'] ?? '';
    $pass = $_POST['pass'] ?? '';

    if (login($name, $pass)) {
        // Post/Redirect/Get: reload the page the user was on, now logged in.
        redirectTo('index.php?page=' . urlencode((string) $page));
    } else {
        // Authentication failed - send them to the registration page.
        redirectTo('index.php?page=4');
    }
}

// --- Logout handler ---------------------------------------------------
if (isset($_GET['logout'])) {
    unset($_SESSION['registered_user']);
    session_regenerate_id(true);
    session_destroy();
    redirectTo('index.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <title>Site1</title>
</head>

<body>
    <div class="container">
        <header class="row align-items-center py-2 border-bottom">
            <div class="col-12 col-md-6">
                <h1 class="h3 mb-0">My First PHP Website</h1>
            </div>
            <div class="col-12 col-md-6 mt-2 mt-md-0 text-md-end">
                <?php $currentUser = $_SESSION['registered_user'] ?? null; ?>
                <?php if ($currentUser !== null): ?>
                    <span class="me-2">Hello, <strong><?= htmlspecialchars($currentUser) ?></strong>!</span>
                    <a href="index.php?logout=1" class="btn btn-outline-secondary btn-sm">Logout</a>
                <?php else: ?>
                    <form action="index.php?page=<?= htmlspecialchars((string) $page) ?>" method="post"
                        class="d-flex gap-2 justify-content-md-end">
                        <input type="text" name="login" class="form-control form-control-sm" style="max-width:130px"
                            placeholder="login" required>
                        <input type="password" name="pass" class="form-control form-control-sm" style="max-width:130px"
                            placeholder="password" required>
                        <button type="submit" name="loginbtn" class="btn btn-primary btn-sm">Login</button>
                    </form>
                <?php endif; ?>
            </div>
        </header>
        <nav class="row mt-3">
            <div class="col-12">
                <?php include_once 'pages/menu.php'; ?>
            </div>
        </nav>
        <section class="row mt-3">
            <div class="col-12">
                <?php
                include_once match ($page) {
                    '2' => 'pages/upload.php',
                    '3' => 'pages/gallery.php',
                    '4' => 'pages/registration.php',
                    default => 'pages/home.php',
                };
                ?>
            </div>
        </section>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous">
    </script>

</body>

</html>
