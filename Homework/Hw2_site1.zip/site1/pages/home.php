<?php declare(strict_types=1); ?>
<h1>Home</h1>
<p>
    Welcome to our first PHP website. Use the menu above to upload pictures on the
    <strong>Upload</strong> page (registered users only), browse them in the
    <strong>Gallery</strong>, or create an account on the <strong>Registration</strong> page.
</p>
