<?php declare(strict_types=1); $page = $_GET['page'] ?? 1; ?>
<ul class="nav nav-pills">
    <li class="nav-item">
        <a href="index.php?page=1" class="nav-link <?= $page == 1 ? 'active' : '' ?>">Home</a>
    </li>
    <li class="nav-item">
        <a href="index.php?page=2" class="nav-link <?= $page == 2 ? 'active' : '' ?>">UPLOAD</a>
    </li>
    <li class="nav-item">
        <a href="index.php?page=3" class="nav-link <?= $page == 3 ? 'active' : '' ?>">GALLERY</a>
    </li>
    <li class="nav-item">
        <a href="index.php?page=4" class="nav-link <?= $page == 4 ? 'active' : '' ?>">REGISTRATION</a>
    </li>
</ul>
