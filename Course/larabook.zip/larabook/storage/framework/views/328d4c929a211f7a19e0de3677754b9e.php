<?php $__env->startSection('content'); ?>
    <h4><?php echo e($page ?? ''); ?></h4>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if(session('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('topics.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="topicname" class="form-label">Topic name</label>
            <input type="text" id="topicname" name="topicname" class="form-control" value="<?php echo e(old('topicname')); ?>">
            <?php $__errorArgs = ['topicname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div id="validationCustom01Feedback" class="invalid-feedback"><?php echo e($error); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-success" type="submit">Add Topic</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Zy\STEP\PHP\PHP_Course\Course\larabook\resources\views/topic/create.blade.php ENDPATH**/ ?>