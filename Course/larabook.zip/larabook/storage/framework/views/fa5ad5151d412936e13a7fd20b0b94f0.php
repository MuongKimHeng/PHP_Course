<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('topics.search')); ?>" class="input-group mb-3">
    <?php echo csrf_field(); ?>
    <input type="text" name="searchform" class="form-control" placeholder="Enter Topic">
    <button class="btn btn-success" type="submit">Search</button>
</form>

    <div class="row">
        <div class="col-md-3">
            <ul class="list-unstyled">
                <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('topics.show', $t)); ?>">
                            <?php echo e($t->topicname); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="col-md-9">
            
            <?php if($topic): ?>
                <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-4">
                        <h2><?php echo e($b->title); ?></h2>
                        
                        <?php if($b->image_path): ?>
                            <img src="<?php echo e(asset('storage/' . $b->image_path)); ?>" height="150" class="float-start me-3" alt="">
                        <?php endif; ?>
                        <p><?php echo e($b->content); ?></p>
                        <a class="btn btn-sm btn-info" href="<?php echo e(route('blocks.edit', $b)); ?>">
                            Edit
                        </a>

                        
                        <form method="POST" action="<?php echo e(route('blocks.destroy', $b)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" type="submit">
                                Delete
                            </button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Zy\STEP\PHP\PHP_Course\Course\larabook\resources\views/topic/index.blade.php ENDPATH**/ ?>