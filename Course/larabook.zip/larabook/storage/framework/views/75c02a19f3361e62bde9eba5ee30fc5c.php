<?php $__env->startSection('content'); ?>
    <h4><?php echo e($page); ?></h4>
    <form method="POST" action="<?php echo e(route('blocks.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="topic_id" class="form-label">Select Topic</label>
            <select id="topic_id" name="topic_id" class="form-select">
                <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($id); ?>" <?php if(old('topic_id') == $id): echo 'selected'; endif; ?>>
                        <?php echo e($name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <a href="<?php echo e(route('topics.create')); ?>" class="btn btn-sm btn-info mt-2">
                Add new Topic
            </a>
        </div>

        <div class="mb-3">
            <label for="title" class="form-label">Block Title</label>
            <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title')); ?>">
        </div>

        <div class="mb-3">
            <label for="content" class="form-label">Add Content</label>
            <textarea id="content" name="content" rows="5" class="form-control"><?php echo e(old('content')); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="image" class="form-label">Add Image</label>
            <input type="file" id="image" name="image" class="form-control">
        </div>
        <button class="btn btn-success" type="submit">Add Block</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Zy\STEP\PHP\PHP_Course\Course\larabook\resources\views/block/create.blade.php ENDPATH**/ ?>