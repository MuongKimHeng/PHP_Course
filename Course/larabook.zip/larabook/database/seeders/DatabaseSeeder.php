<?php

namespace Database\Seeders;

use App\Models\Block;
use App\Models\Topic;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::factory()->create([
            'name' => 'KimHeng',
            'email' => 'hengzy0209@gmail.com',
            'email_verified_at' => now(),
            'password' => '12345678'
        ]);

        Topic::factory(5)->has(Block::factory(3))->create();
    }
}
